var searchData=
[
  ['gerenciaraeroportos_0',['gerenciarAeroportos',['../classgerenciar_aeroportos.html',1,'']]],
  ['gerenciartransportes_1',['gerenciarTransportes',['../classgerenciar_transportes.html',1,'']]]
];
