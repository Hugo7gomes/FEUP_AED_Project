var indexSectionsWithContent =
{
  0: "abcdefgilmoprstuv~",
  1: "abcgilpstuv",
  2: "im",
  3: "abcdgilmpstuv",
  4: "abcdefgilmoprstuv~",
  5: "bi"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Friends"
};

