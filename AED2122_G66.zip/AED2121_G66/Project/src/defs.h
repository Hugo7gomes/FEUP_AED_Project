
#ifndef DEFS_H
#define DEFS_H

using  namespace  std;

#include <cstdio>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <iterator>
#include <algorithm>
#include <sstream>
#include <ctime>
#include <conio.h>
#include <list>
#include <queue>
#include <stack>
#include <sstream>
#include <cctype>



#endif //DEFS_H
